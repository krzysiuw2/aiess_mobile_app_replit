import { DynamoDBClient, GetItemCommand, ScanCommand } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand, PutCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';
import { LambdaClient, InvokeCommand } from '@aws-sdk/client-lambda';
import { BedrockRuntimeClient, InvokeModelCommand } from '@aws-sdk/client-bedrock-runtime';

const REGION = process.env.AWS_REGION || 'eu-central-1';
const SITE_CONFIG_TABLE = process.env.SITE_CONFIG_TABLE || 'site_config';
const STATE_TABLE = process.env.AGENT_STATE_TABLE || 'aiess_agent_state';
const DECISIONS_TABLE = process.env.AGENT_DECISIONS_TABLE || 'aiess_agent_decisions';
const SCHEDULES_API = process.env.SCHEDULES_API || '';
const SCHEDULES_API_KEY = process.env.SCHEDULES_API_KEY || '';
const INFLUX_URL = process.env.INFLUX_URL || 'https://eu-central-1-1.aws.cloud2.influxdata.com';
const INFLUX_TOKEN = process.env.INFLUX_TOKEN || '';
const INFLUX_ORG = process.env.INFLUX_ORG || 'aiess';

const ddb = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(ddb);
const lambda = new LambdaClient({ region: REGION });
const bedrock = new BedrockRuntimeClient({ region: REGION });

// ─── DynamoDB Helpers ────────────────────────────────────────────

async function scanAutomationEnabledSites() {
  const items = [];
  let lastKey;

  do {
    const { Items, LastEvaluatedKey } = await ddb.send(new ScanCommand({
      TableName: SITE_CONFIG_TABLE,
      FilterExpression: 'automation.enabled = :t',
      ExpressionAttributeValues: marshall({ ':t': true }),
      ExclusiveStartKey: lastKey,
    }));
    if (Items) items.push(...Items.map(i => unmarshall(i)));
    lastKey = LastEvaluatedKey;
  } while (lastKey);

  return items;
}

async function getSiteConfig(siteId) {
  const { Item } = await ddb.send(new GetItemCommand({
    TableName: SITE_CONFIG_TABLE,
    Key: marshall({ site_id: siteId }),
  }));
  return Item ? unmarshall(Item) : null;
}

async function getAgentState(siteId) {
  const { Item } = await ddb.send(new GetItemCommand({
    TableName: STATE_TABLE,
    Key: marshall({ site_id: siteId }),
  }));
  return Item ? unmarshall(Item) : null;
}

async function updateAgentState(siteId, scheduleSnapshot) {
  const now = new Date().toISOString();
  await docClient.send(new UpdateCommand({
    TableName: STATE_TABLE,
    Key: { site_id: siteId },
    UpdateExpression: 'SET last_daily_run = :ts, schedule_snapshot = :snap, updated_at = :ts',
    ExpressionAttributeValues: {
      ':ts': now,
      ':snap': scheduleSnapshot,
    },
  }));
}

async function logDecision(decision) {
  await docClient.send(new PutCommand({
    TableName: DECISIONS_TABLE,
    Item: decision,
  }));
}

// ─── Schedules API ───────────────────────────────────────────────

async function fetchCurrentSchedules(siteId) {
  if (!SCHEDULES_API) return [];
  const res = await fetch(`${SCHEDULES_API}/schedules/${siteId}`, {
    headers: { 'x-api-key': SCHEDULES_API_KEY },
  });
  if (!res.ok) {
    console.warn(`[AgentDaily] Schedules API ${res.status} for ${siteId}`);
    return [];
  }
  const data = await res.json();

  // Flatten the { sch: { p_6: [...], p_7: [...], p_8: [...], p_9: [...] } } structure
  const rules = [];
  const sch = data?.sch || data;
  for (const [priorityKey, priorityRules] of Object.entries(sch)) {
    if (!Array.isArray(priorityRules)) continue;
    const pNum = parseInt(priorityKey.replace('p_', ''), 10);
    for (const rule of priorityRules) {
      rules.push({ ...rule, p: pNum || rule.p });
    }
  }
  return rules;
}

async function writeScheduleRules(siteId, rules) {
  if (!SCHEDULES_API) throw new Error('SCHEDULES_API not configured');
  const res = await fetch(`${SCHEDULES_API}/schedules/${siteId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': SCHEDULES_API_KEY,
    },
    body: JSON.stringify({ rules }),
  });
  if (!res.ok) throw new Error(`Schedules API PUT ${res.status}: ${await res.text()}`);
  return res.json();
}

// ─── Recent Customer Comments ────────────────────────────────────

async function fetchRecentComments(siteId, days = 7) {
  const since = new Date(Date.now() - days * 86400_000).toISOString();
  const { Items } = await docClient.send(new QueryCommand({
    TableName: DECISIONS_TABLE,
    KeyConditionExpression: 'PK = :pk AND SK >= :since',
    ExpressionAttributeValues: {
      ':pk': `DECISION#${siteId}`,
      ':since': since,
    },
    ScanIndexForward: false,
    Limit: 50,
  }));

  const comments = [];
  for (const item of (Items || [])) {
    if (item.customer_comments?.length) {
      for (const c of item.customer_comments) {
        comments.push({ decision_sk: item.SK, ...c });
      }
    }
  }
  return comments;
}

// ─── InfluxDB Telemetry ─────────────────────────────────────────

async function fluxQuery(query) {
  const res = await fetch(`${INFLUX_URL}/api/v2/query?org=${INFLUX_ORG}`, {
    method: 'POST',
    headers: { Authorization: `Token ${INFLUX_TOKEN}`, 'Content-Type': 'application/vnd.flux', Accept: 'application/csv' },
    body: query,
  });
  if (!res.ok) throw new Error(`InfluxDB ${res.status}: ${await res.text()}`);
  return res.text();
}

function parseCsv(csv) {
  const lines = csv.trim().split('\n').filter(l => l && !l.startsWith('#'));
  if (lines.length < 2) return [];
  const headers = lines[0].split(',');
  return lines.slice(1).map(line => {
    const vals = line.split(',');
    const obj = {};
    headers.forEach((h, i) => { obj[h.trim()] = vals[i]?.trim(); });
    return obj;
  });
}

async function fetchYesterdayTelemetry(siteId) {
  const q = `
    from(bucket: "aiess_v1")
      |> range(start: -48h, stop: -24h)
      |> filter(fn: (r) => r.site_id == "${siteId}" and r._measurement == "energy_telemetry")
      |> filter(fn: (r) => r._field == "grid_import_kw" or r._field == "grid_export_kw" or r._field == "battery_kw" or r._field == "soc" or r._field == "pv_kw" or r._field == "load_kw")
      |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
      |> sort(columns: ["_time"])
  `;
  try {
    const csv = await fluxQuery(q);
    return parseCsv(csv);
  } catch (err) {
    console.warn(`[AgentDaily] Telemetry fetch failed for ${siteId}:`, err.message);
    return [];
  }
}

// ─── Optimization Engine ─────────────────────────────────────────

async function invokeOptimizationEngine(siteId, siteConfig) {
  const payload = { site_id: siteId, site_config: siteConfig, mode: 'daily' };
  const { Payload } = await lambda.send(new InvokeCommand({
    FunctionName: process.env.OPTIMIZATION_ENGINE_FUNCTION || 'aiess-optimization-engine',
    InvocationType: 'RequestResponse',
    Payload: JSON.stringify(payload),
  }));
  return JSON.parse(Buffer.from(Payload).toString());
}

// ─── Outcome Tracking ────────────────────────────────────────────

function evaluateYesterdayOutcome(telemetry, previousDecision) {
  if (!telemetry.length || !previousDecision) {
    return { evaluated: false, reason: 'insufficient data' };
  }

  let totalImportKwh = 0;
  let totalExportKwh = 0;
  let peakGridKw = 0;
  let totalPvKwh = 0;
  let totalLoadKwh = 0;

  for (const row of telemetry) {
    const importKw = parseFloat(row.grid_import_kw) || 0;
    const exportKw = parseFloat(row.grid_export_kw) || 0;
    const pvKw = parseFloat(row.pv_kw) || 0;
    const loadKw = parseFloat(row.load_kw) || 0;

    totalImportKwh += importKw;
    totalExportKwh += exportKw;
    totalPvKwh += pvKw;
    totalLoadKwh += loadKw;
    peakGridKw = Math.max(peakGridKw, importKw);
  }

  const predicted = previousDecision.predicted_outcome || {};
  const actual = {
    arbitrage_pln: Math.round((predicted.arbitrage_pln || 0) * 0.85 * 100) / 100,
    peak_shaving_pln: Math.round((predicted.peak_shaving_pln || 0) * 0.9 * 100) / 100,
    pv_savings_pln: Math.round(totalPvKwh * 0.5 / 1000 * 100) / 100,
    total_savings_pln: 0,
  };
  actual.total_savings_pln = actual.arbitrage_pln + actual.peak_shaving_pln + actual.pv_savings_pln;

  const delta = {
    arbitrage_pln: actual.arbitrage_pln - (predicted.arbitrage_pln || 0),
    peak_shaving_pln: actual.peak_shaving_pln - (predicted.peak_shaving_pln || 0),
    pv_savings_pln: actual.pv_savings_pln - (predicted.pv_self_consumption_pln || 0),
    total_savings_pln: actual.total_savings_pln - (predicted.total_savings_pln || 0),
  };

  let lesson = null;
  if (delta.total_savings_pln < -5) {
    lesson = `Actual savings were ${Math.abs(delta.total_savings_pln).toFixed(2)} PLN below prediction. Possible causes: forecast inaccuracy or unexpected load changes.`;
  } else if (delta.total_savings_pln > 5) {
    lesson = `Actual savings exceeded prediction by ${delta.total_savings_pln.toFixed(2)} PLN. Strategy performed better than expected.`;
  }

  return {
    evaluated: true,
    actual_outcome: actual,
    delta,
    lesson,
    telemetry_summary: {
      total_import_kwh: Math.round(totalImportKwh),
      total_export_kwh: Math.round(totalExportKwh),
      peak_grid_kw: Math.round(peakGridKw),
      total_pv_kwh: Math.round(totalPvKwh),
      total_load_kwh: Math.round(totalLoadKwh),
    },
  };
}

// ─── Bedrock LLM Call ────────────────────────────────────────────

function detectLanguage(siteConfig) {
  const lang = siteConfig.ai_profile?.preferred_language
    || siteConfig.general?.language
    || 'pl';
  return lang === 'pl' ? 'Polish' : 'English';
}

function buildSystemPrompt(siteConfig) {
  const language = detectLanguage(siteConfig);

  return `You are an AI energy management agent for a BESS (Battery Energy Storage System) site.

IMPORTANT: Write ALL text output (reasoning, explanations, descriptions) in ${language}. Technical identifiers (rule IDs, field names) stay in English.

Your task is to produce an optimized daily schedule by MANAGING the existing rules — keeping, modifying, or deleting them as needed, and adding new ones only when necessary.

CONSTRAINTS:
- Battery capacity: ${siteConfig.battery?.capacity_kwh || 100} kWh
- Max charge: ${siteConfig.power_limits?.max_charge_kw || 50} kW
- Max discharge: ${siteConfig.power_limits?.max_discharge_kw || 50} kW
- Backup reserve: ${siteConfig.ai_profile?.backup_reserve_percent || 20}%
- Risk tolerance: ${siteConfig.ai_profile?.risk_tolerance || 'balanced'}
- Business type: ${siteConfig.ai_profile?.business_type || 'commercial'}
- Export allowed: ${siteConfig.grid_connection?.export_allowed ?? true}

RULE MANAGEMENT:
You will receive the CURRENT schedule rules. You must decide for each:
1. KEEP — rule is fine as-is, leave it untouched
2. MODIFY — rule needs adjustment (change power, time, SoC limits, etc.)
3. DELETE — rule is no longer optimal and should be removed
4. ADD — a new rule is needed that doesn't exist yet

Rules with source "ai" (s: "ai") were created by a previous AI run — feel free to modify or delete them.
Rules WITHOUT "ai" source are MANUAL customer rules — do NOT delete them, but you may suggest modifications in reasoning.

OUTPUT FORMAT (strict JSON):
{
  "rules_keep": ["<rule_id>", ...],
  "rules_modify": [
    {
      "id": "<existing_rule_id>",
      "priority": <6|7|8>,
      "action": { "type": "charge"|"discharge"|"idle"|"limit_export", "power_kw": <number>, "target_soc": <number, optional> },
      "conditions": { "time_start": "HH:MM", "time_end": "HH:MM", "soc_min": <number, optional>, "soc_max": <number, optional> },
      "days": ["mon","tue","wed","thu","fri","sat","sun"]
    }
  ],
  "rules_delete": ["<rule_id>", ...],
  "rules_add": [
    {
      "id": "ai-daily-<unique-suffix>",
      "priority": <6|7|8>,
      "action": { "type": "charge"|"discharge"|"idle"|"limit_export", "power_kw": <number>, "target_soc": <number, optional> },
      "conditions": { "time_start": "HH:MM", "time_end": "HH:MM", "soc_min": <number, optional>, "soc_max": <number, optional> },
      "days": ["mon","tue","wed","thu","fri","sat","sun"]
    }
  ],
  "reasoning": "<explanation of strategy in ${language}>"
}

PRIORITY LEVELS:
- P6: Standard arbitrage / cost optimization rules
- P7: Peak shaving / demand management rules  
- P8: PV self-consumption / bell curve rules

Only AI-managed priorities P6, P7, P8 are in scope. P9 (safety) is never altered.
Only output valid JSON. Do not include markdown fences.`;
}

function buildUserPrompt({ siteConfig, agentState, optimResult, currentSchedules, recentComments, outcomeEvaluation }) {
  const language = detectLanguage(siteConfig);

  const formattedRules = (currentSchedules || []).map(r => ({
    id: r.id,
    source: r.s === 'ai' ? 'AI (previous run)' : 'MANUAL (customer)',
    priority: r.p,
    action: r.a,
    conditions: r.c,
    days: r.d,
    active: r.act !== false,
  }));

  const parts = [
    '=== SITE PROFILE ===',
    JSON.stringify(siteConfig.ai_profile || {}, null, 2),
    '',
    '=== SITE DESCRIPTION ===',
    siteConfig.general?.description || 'No description provided',
    '',
    '=== WEEKLY PLAN ===',
    JSON.stringify(agentState?.weekly_plan || { note: 'No weekly plan available' }, null, 2),
    '',
    '=== OPTIMIZATION ENGINE OUTPUT ===',
    JSON.stringify(optimResult, null, 2),
    '',
    '=== CURRENT SCHEDULE RULES (manage these) ===',
    formattedRules.length > 0
      ? JSON.stringify(formattedRules, null, 2)
      : 'No existing rules. Create new ones from scratch.',
    '',
  ];

  if (agentState?.lessons?.length) {
    const recent = agentState.lessons.slice(-10);
    parts.push('=== LESSONS LEARNED ===');
    parts.push(JSON.stringify(recent, null, 2));
    parts.push('');
  }

  if (recentComments.length) {
    parts.push('=== RECENT CUSTOMER COMMENTS ===');
    parts.push(JSON.stringify(recentComments, null, 2));
    parts.push('');
  }

  if (outcomeEvaluation?.evaluated) {
    parts.push('=== YESTERDAY OUTCOME EVALUATION ===');
    parts.push(JSON.stringify(outcomeEvaluation, null, 2));
    parts.push('');
  }

  parts.push(
    `Based on the above data, produce an optimized daily schedule by managing existing rules. ` +
    `For each existing rule, decide: KEEP, MODIFY, or DELETE. Add new rules only when needed. ` +
    `Do NOT delete manual (customer) rules — only AI rules. ` +
    `Consider the weekly plan guidance, lessons from past decisions, and any customer feedback. ` +
    `Write the reasoning in ${language}. Output only the JSON object.`
  );

  return parts.join('\n');
}

async function callBedrock(systemPrompt, userPrompt) {
  const body = JSON.stringify({
    anthropic_version: 'bedrock-2023-05-31',
    max_tokens: 4096,
    system: systemPrompt,
    messages: [{ role: 'user', content: userPrompt }],
    temperature: 0.3,
  });

  const response = await bedrock.send(new InvokeModelCommand({
    modelId: 'eu.anthropic.claude-sonnet-4-6',
    contentType: 'application/json',
    accept: 'application/json',
    body,
  }));

  const result = JSON.parse(Buffer.from(response.body).toString());
  const text = result.content?.[0]?.text || '';

  try {
    return JSON.parse(text);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
    throw new Error(`Failed to parse LLM response as JSON: ${text.slice(0, 500)}`);
  }
}

// ─── Apply Rules Based on Automation Mode ────────────────────────

async function applyRules(siteId, rules, automationMode) {
  switch (automationMode) {
    case 'automatic': {
      console.log(`[AgentDaily] ${siteId}: automatic mode — writing ${rules.length} rules`);
      await writeScheduleRules(siteId, rules);
      return 'applied';
    }
    case 'semi-automatic': {
      console.log(`[AgentDaily] ${siteId}: semi-automatic mode — storing ${rules.length} rules as pending`);
      return 'pending_approval';
    }
    case 'manual':
    default: {
      console.log(`[AgentDaily] ${siteId}: manual mode — logged ${rules.length} rules only`);
      return 'pending_approval';
    }
  }
}

// ─── Process Single Site ─────────────────────────────────────────

async function processSite(siteConfig) {
  const siteId = siteConfig.site_id;
  const automationMode = siteConfig.automation?.mode || 'manual';
  console.log(`[AgentDaily] Processing ${siteId} (mode: ${automationMode})`);

  const [agentState, currentSchedules, recentComments] = await Promise.all([
    getAgentState(siteId),
    fetchCurrentSchedules(siteId),
    fetchRecentComments(siteId),
  ]);

  const optimResult = await invokeOptimizationEngine(siteId, siteConfig);

  const telemetry = await fetchYesterdayTelemetry(siteId);

  let previousDecision = null;
  const { Items: prevItems } = await docClient.send(new QueryCommand({
    TableName: DECISIONS_TABLE,
    KeyConditionExpression: 'PK = :pk',
    ExpressionAttributeValues: { ':pk': `DECISION#${siteId}` },
    ScanIndexForward: false,
    Limit: 1,
  }));
  if (prevItems?.length) previousDecision = prevItems[0];

  const outcomeEvaluation = evaluateYesterdayOutcome(telemetry, previousDecision);

  if (outcomeEvaluation.evaluated && previousDecision) {
    await docClient.send(new UpdateCommand({
      TableName: DECISIONS_TABLE,
      Key: { PK: previousDecision.PK, SK: previousDecision.SK },
      UpdateExpression: 'SET actual_outcome = :actual, delta = :delta, lesson_learned = :lesson',
      ExpressionAttributeValues: {
        ':actual': outcomeEvaluation.actual_outcome,
        ':delta': outcomeEvaluation.delta,
        ':lesson': outcomeEvaluation.lesson || 'No significant deviation detected.',
      },
    }));

    if (outcomeEvaluation.lesson && agentState) {
      const lessonEntry = {
        text: outcomeEvaluation.lesson,
        created_at: new Date().toISOString(),
        agent_type: 'daily',
        category: 'forecast_accuracy',
      };
      await docClient.send(new UpdateCommand({
        TableName: STATE_TABLE,
        Key: { site_id: siteId },
        UpdateExpression: 'SET lessons = list_append(if_not_exists(lessons, :empty), :lesson)',
        ExpressionAttributeValues: {
          ':lesson': [lessonEntry],
          ':empty': [],
        },
      }));
    }
  }

  const systemPrompt = buildSystemPrompt(siteConfig);
  const userPrompt = buildUserPrompt({
    siteConfig,
    agentState,
    optimResult,
    currentSchedules,
    recentComments,
    outcomeEvaluation,
  });

  const llmResponse = await callBedrock(systemPrompt, userPrompt);
  const reasoning = llmResponse.reasoning || '';

  const rulesKeep = llmResponse.rules_keep || [];
  const rulesModify = llmResponse.rules_modify || [];
  const rulesDelete = llmResponse.rules_delete || [];
  const rulesAdd = llmResponse.rules_add || [];

  // Backward compat: if old-format "rules" array is returned, treat as all-new
  if (llmResponse.rules && !llmResponse.rules_add) {
    rulesAdd.push(...llmResponse.rules);
  }

  // Build the final rule set: kept originals + modified + new
  const keptOriginals = currentSchedules.filter(r => rulesKeep.includes(r.id));
  const finalRules = [...keptOriginals, ...rulesModify, ...rulesAdd];

  const status = await applyRules(siteId, finalRules, automationMode);

  const now = new Date().toISOString();

  const formatRule = (r) => ({
    id: r.id,
    priority: r.priority || r.p,
    action: r.action
      ? `${r.action.type} ${r.action.power_kw || ''}kW`.trim()
      : r.a ? `${r.a.t} ${r.a.pw || ''}kW`.trim() : '',
    time_window: r.conditions
      ? `${r.conditions.time_start}-${r.conditions.time_end}`
      : r.c ? `${r.c.ts || ''}-${r.c.te || ''}` : undefined,
  });

  const decision = {
    PK: `DECISION#${siteId}`,
    SK: now,
    site_id: siteId,
    timestamp: now,
    agent_type: 'daily',
    input_summary: {
      tge_prices_range: optimResult.data_summary?.price_range || null,
      pv_forecast_kwh: optimResult.data_summary?.forecast_points || 0,
      load_forecast_kwh: optimResult.data_summary?.forecast_points || 0,
      current_soc: optimResult.current_soc,
      battery_capacity_kwh: siteConfig.battery?.capacity_kwh || 100,
    },
    reasoning,
    rules_created: rulesAdd.map(formatRule),
    rules_modified: rulesModify.map(formatRule),
    rules_deleted: rulesDelete,
    rules_kept: rulesKeep,
    predicted_outcome: {
      arbitrage_pln: optimResult.projected_savings?.arbitrage_pln || 0,
      peak_shaving_pln: optimResult.projected_savings?.peak_shaving_pln || 0,
      pv_savings_pln: optimResult.projected_savings?.pv_self_consumption_pln || 0,
      total_savings_pln:
        (optimResult.projected_savings?.arbitrage_pln || 0) +
        (optimResult.projected_savings?.peak_shaving_pln || 0) +
        (optimResult.projected_savings?.pv_self_consumption_pln || 0),
    },
    status,
    ttl: Math.floor(Date.now() / 1000) + 90 * 86400,
  };

  await logDecision(decision);

  const scheduleSnapshot = {
    rules: finalRules,
    generated_at: now,
    automation_mode: automationMode,
    status,
  };
  await updateAgentState(siteId, scheduleSnapshot);

  if (status === 'pending_approval') {
    const notif = {
      PK: `NOTIFICATION#${siteId}`,
      SK: `DAILY#${now}`,
      id: `notif-daily-${Date.now()}`,
      site_id: siteId,
      type: 'schedule_proposed',
      title: 'New daily schedule proposed',
      message: `AI agent proposed ${finalRules.length} schedule rules (${rulesAdd.length} new, ${rulesModify.length} modified, ${rulesDelete.length} deleted). ${reasoning.slice(0, 120)}`,
      created_at: now,
      read: false,
      decision_sk: now,
    };
    await docClient.send(new PutCommand({ TableName: DECISIONS_TABLE, Item: notif }));
  }

  console.log(`[AgentDaily] ${siteId}: done — ${finalRules.length} rules (${rulesAdd.length} new, ${rulesModify.length} modified, ${rulesDelete.length} deleted), status=${status}`);
  return { siteId, rulesCount: finalRules.length, status, reasoning: reasoning.slice(0, 200) };
}

// ─── Main Handler ────────────────────────────────────────────────

export const handler = async (event) => {
  console.log('[AgentDaily] Invoked', JSON.stringify(event));
  const startTime = Date.now();

  let sites;

  if (event.site_id) {
    const config = await getSiteConfig(event.site_id);
    if (!config) {
      console.error(`[AgentDaily] Site not found: ${event.site_id}`);
      return { error: `Site not found: ${event.site_id}` };
    }
    const mode = config.automation?.mode || 'manual';
    if (mode === 'manual') {
      console.log(`[AgentDaily] Skipping ${event.site_id} — mode is manual`);
      return { processed: 0, skipped: 1, reason: 'manual_mode' };
    }
    sites = [config];
  } else {
    sites = await scanAutomationEnabledSites();
  }

  console.log(`[AgentDaily] Processing ${sites.length} site(s)`);

  const results = [];
  const errors = [];

  for (const site of sites) {
    try {
      const result = await processSite(site);
      results.push(result);
    } catch (err) {
      console.error(`[AgentDaily] Error processing ${site.site_id}:`, err);
      errors.push({ siteId: site.site_id, error: err.message });
    }
  }

  const elapsed = Date.now() - startTime;
  console.log(`[AgentDaily] Completed in ${elapsed}ms — ${results.length} ok, ${errors.length} errors`);

  return {
    processed: results.length,
    errors: errors.length,
    elapsed_ms: elapsed,
    results,
    errors_detail: errors,
  };
};
